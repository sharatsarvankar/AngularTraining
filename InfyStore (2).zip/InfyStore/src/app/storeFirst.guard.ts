import { Route, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { StorComponent } from './store/stor.component';
import { Injectable } from '@angular/core';

@Injectable()
export class StoreFirstGuard{
    private firstNavigation = true;

    constructor(
        private router:Router
    )
    {}
  // this code for the restrict url
  // url should be go to home page only
    canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot ): boolean
    {
      if(this.firstNavigation) {
          this.firstNavigation = false;
          if(route.component != StorComponent){
              this.router.navigateByUrl("/");
              return false;
          }

      }
      return true;
    }
}