import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StorComponent } from './store/stor.component';
import { CartDetailComponent } from './store/cart-detail.component';
import { CheckoutComponent } from './store/checkout.component';
import { StoreFirstGuard } from './storeFirst.guard';
import { FormsModule } from '@angular/forms';


const routes: Routes = [
  {path:"store",component: StorComponent, canActivate:[StoreFirstGuard]},
  {path:"cart",component: CartDetailComponent , canActivate:[StoreFirstGuard]},
  {path:"checkout",component: CheckoutComponent , canActivate:[StoreFirstGuard]},
  
  {path:"admin",loadChildren: "./admin/admin.module#AdminModule" ,canActivate:[StoreFirstGuard]},
  
  {path:"**", redirectTo: "/store"} // for else condition
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [StoreFirstGuard]
})
export class AppRoutingModule { }
