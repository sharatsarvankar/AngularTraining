import { Component, OnInit } from '@angular/core';
import { OrderReposiorty } from '../model/order.repository';
import { Order } from '../model/order.model';
import {NgForm} from '@angular/forms'

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit {

  orderSent:boolean=false;
  submitted:boolean=false;
  constructor(
 public repository:OrderReposiorty,
 public order:Order

  ) { }

  ngOnInit() {
  }
 
  submitOrder(form: NgForm){
    this.submitted=true;
    if(form.valid){
      this.repository.saveOrder(this.order).subscribe(Order =>
        {
          this.order.clear();
          this.orderSent = true;
          this.submitted = false;
        })
    }
  }
}
