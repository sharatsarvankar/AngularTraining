import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StaticDataSource } from './static.datasource';
import { ProductRepository } from './product.repository';
import { Cart } from './cart.model';
import { Order } from './order.model';
import { OrderReposiorty } from './order.repository';
import { RestDataSource } from './rest.datasource';
import { HttpClientModule } from '@angular/common/http';
import { AuthService } from './auth.service';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,HttpClientModule
  ], 
  //providers:[StaticDataSource,ProductRepository,Cart,Order,OrderReposiorty]
  //use rest service and replace statics 
  providers:[ProductRepository,Cart,Order,OrderReposiorty, { provide:StaticDataSource , useClass:RestDataSource},RestDataSource,AuthService]
})
export class ModelModule { }
